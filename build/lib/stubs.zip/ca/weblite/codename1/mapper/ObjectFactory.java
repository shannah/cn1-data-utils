package ca.weblite.codename1.mapper;


/**
 * 
 *  @author shannah
 */
public interface ObjectFactory {

	public Object createObject(Class klass);
}
