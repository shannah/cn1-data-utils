package ca.weblite.codename1.mapper.test;


/**
 * 
 *  @author shannah
 */
public interface SomeInterface {

	public java.util.List getStrings();

	public void setStrings(java.util.List strings);
}
